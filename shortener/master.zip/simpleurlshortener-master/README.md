# Simple URL Shortener

Source Code of the Code from the article of [Adventure Of Palash](https://palash.tk)

Tools Using : 

- jsonstore.io
- html
- javascript
- jquery

No Need Of Database !

READ THE Original ARTICLE HERE

[![Blog Post](https://palash.tk/assets/images/build_url_shortener.png)](https://dev.to/bauripalash/building-a-simple-url-shortener-with-just-html-and-javascript-16o4)

---
### Buy Me A Coffee!
<a href="https://www.buymeacoffee.com/palash" target="_blank"><img src="https://cdn.buymeacoffee.com/buttons/default-orange.png" alt="Buy Me A Coffee" style="height: 40px !important;width: 80px !important;" ></a>
