<?php
$istrend = true;
include 'header.php';
include "trendfunctions.php";

if( isEssentials() ) 
{
Header( "Location: index.php?l=1" );
exit;
}


if( !$search[dates][fromq] )
{
//    $nodates = true;
    $search[dates][fromq] = 1;
    $search[dates][fromy] = 2013;
    $search[dates][toq] = 4;
    $search[dates][toy] = date( "Y" );
}

if( !$search[dates][toq] )
{
    $search[dates][toq] = $search[dates][fromq];
    $search[dates][toy] = $search[dates][fromy];
}

$quarterstorun = getQuarters( $search[dates][fromq], $search[dates][fromy], $search[dates][toq], $search[dates][toy] );

$pos = $search[peakchart];
if( $pos && strpos( $pos, "client-" ) === false )
{
    $pos = "<" . $pos;
}

$allsongs = getSongIdsWithinQuarter( $newarrivalsonly, $search[dates][fromq], $search[dates][fromy], $search[dates][toq], $search[dates][toy], $pos );


$rows = getRowsComparison( $search, $allsongs );
$colors = array( "#1fb5ad","#fa8564","#efb3e6","#fdd752","#aec785","#9972b5","#91e1dd" ); 
// $colors = array( "#5d97cc","#fb833b", "#aeaeae", "#4b6986", "#7f5237", "#ffffff" ); 
// $colors = array( "#A860AB", "#FF2705", "#FFFF17", "#1DFF0D", "#10FFEF", "#1020FF", "#FF03BC", "#FFAEB3" );

$dataforrows = getTrendDataForRows( $quarterstorun, $search[comparisonaspect], $pos );
if( $help )
{
    print_r( $allsongs );
    print_r( $dataforrows );
}


if( $search[comparisonaspect] == "Number of Songs" || $search[comparisonaspect] == "Number of Weeks" )
{
    include "trend-search-results-table.php";
    exit;
}




?>
<style type="text/css">
	.search-header h1{ float:none; }
	.search-header h2{
    margin-top: 15px;
    color: #7a7a7a;
    font-size: 14px;
	}
    
    ul.instructions li{
         list-style-type: initial!important;
        margin-left:15px!important;
        padding-bottom:6px;
       font-weight: 500;
    }
    
    #chartContainer h2 {
/*    padding-bottom:20px; */
    }
</style>
	<div class="site-body">
        <? include "searchcriteria-trend.php"; ?>
		<section class="search-results-bottom">
			<div class="element-container row">
				<div class="search-container">
					<div class="search-header">
        <h1>TREND SEARCH: <?=strtoupper( getSearchTrendName( $search[comparisonaspect] ) )?></h1>
            <?
            $key = "TREND SEARCH - " . $search[comparisonaspect] . " - " . $searchsubtype . "";
if( $_GET["showkey"] ) echo( "<font color='red'>$key</font><br><Br>" ); 
            $custom = getCustomHover( $key ); ?>

            <h2><?=$custom?$custom:"This search reflects trends occurring within songs that have charted among the Billboard Hot 100 Top Ten."?>
<br><br>
                            <ul class="instructions">
           <li>To add or remove items from the graph below, please click on the item in the legend.</li>
            <li>To view the songs that correspond to a datapoint, hover over the datapoint and click on the link in the pop-up.</li>
                            </ul>


    </h2>
						<a href="trend-search<?=$thetype?"-$thetype":""?>.php?<?=$_SERVER['QUERY_STRING']?>" class="search-header-back">BACK <span class="hide-text">TO SEARCH</span></a>
						<div class="cf"></div>
					</div><!-- /search-header -->
					<div class="search-body">
<span class='showall'>    <a href='#' onClick='showAllGraph( true ); return false' style="background-color: #32323a;display: inline-block;-webkit-border-radius: 3px;-moz-border-radius: 3px;border-radius: 3px;text-align: center;font-size: 14px;color: #ffffff;text-decoration: none;padding: 12px;">Show All</a>      <a href='#' onClick='showAllGraph( false ); return false' style="background-color: #ff6633;display: inline-block;-webkit-border-radius: 3px;-moz-border-radius: 3px;border-radius: 3px;text-align: center;font-size: 14px;color: #ffffff;text-decoration: none;padding: 12px;">Hide All</a></span>
        <a href='#' id="exportjpg" onClick='return false' style="background-color: #aeb2b7;display: inline-block;-webkit-border-radius: 3px;-moz-border-radius: 3px;border-radius: 3px;text-align: center;font-size: 14px;color: #ffffff;text-decoration: none;padding: 12px;">Save As Image</a></span>
<script language='javascript'>

        function saveCanvas()
{
    chart.exportCanvas( chart.canvas, "png", chart.exportFileName);

}
    function showAllGraph( val )
{
    for(i = 0; i <  chart.options.data.length ; i++ )
    {
        chart.options.data[i].visible = val;
    }
    chart.render();
}
</script>    
<!-- begin graph -->
	<div id="chartContainer" style="height:600px;">
	</div>
    <!-- end graph -->    
                        <div class="search-footer">
							<div class="search-footer-left span-3">
								<a href="trend-search<?=$thetype?"-$thetype":""?>.php?<?=$_SERVER['QUERY_STRING']?>" style="float:left;" class="search-header-back">BACK <span class="hide-text">TO SEARCH</span></a>
								<div class="cf"></div>
							</div><!-- /search-footer-left -->
							<div class="search-footer-right span-4">
    <? if( !isStudent() && !isEssentials() ) { ?>
    <a class="black-btn" href="#" data-featherlight="#searchlightbox">SAVE SEARCH</a>
                            <? } ?>
								<a class="orange-btn" href="/trend-search">NEW SEARCH</a>
								<div class="lightbox" id="searchlightbox">
									<div class="save-search-header">
										<h1>SAVE SEARCH</h2>
									</div><!-- /.save-search-header -->
									<div class="save-search-body">
										<label>Name:</label>
										<input type='text' name="searchname" id='searchname' onChange='javascript:document.getElementById( "searchnamehidden").value = this.value; '>
										<a class="black-btn" href="#" onClick='javascript:saveSearch( "saved", $(this).prev().val() ); return false'>SAVE</a>
										<div class="cf"></div>
									</div><!-- /.save-search-body -->
								</div><!-- #searchlightbox -->
							</div><!-- /search-footer-right -->
							<div class="cf"></div>
						</div><!-- /.search-footer -->
					</div><!-- /search-body -->
				</div><!-- /.search-container -->
			</div><!-- /.row -->
		</section><!-- /.search-results-bottom -->
	</div><!-- /.site-body -->
      <input type='hidden' name="searchnamehidden" id='searchnamehidden'>
    <script>
		var sessid = "<?=session_id()?>";
		var searchType = "<?=$searchtype?$searchtype:"Trend"?>";
	var searchName = "TREND SEARCH: <?=strtoupper( getSearchTrendName( $search[comparisonaspect] ) )?>";

saveSearch( "recent" );
$(document).ready(function(){
        $("a.expand-btn").click(function(){
            $("a.expand-btn").toggleClass("collapse-btn");
            $("#search-hidden").toggleClass("hide show");
        });
    });

    </script>

 <!-- end chart code -->
    <? $gray = "#444444"; ?>
    <? $labelextra = "%";

if( $search[comparisonaspect] == "Average Section Length" )
    $labelextra = "";
?>
	<script type="text/javascript">
		window.onload = function () {
			CanvasJS.addColorSet("hsdColors",
                [//colorSet Array

                "#5d97cc",
                "#fb833b",
                "#aeaeae"
                // "#3CB371",
                // "#90EE90"                
                ]);

			chart = new CanvasJS.Chart("chartContainer", {
				colorSet: "hsdColors",
				exportEnabled: true,
				title: {
				text: "<?=str_replace( '"', '\"', $possiblesearchfunctions[$search[comparisonaspect]] )?>",
                    fontColor: "#888888",
                    // fontColor: "#ffffff",
                    fontFamily: "Open Sans",
                    fontWeight: "bold",
					fontSize: 25
				},
				subtitles:[
<? $descr = db_query_first_cell( "select Value from graphnotes where Name = '" . mysql_escape_string( $possiblesearchfunctions[$search[comparisonaspect]] ). "' " );

$descr = nl2br( trim( $descr ) );

if( $descr )
{
?>

            {
              text: "<?=str_replace( '"', '\"', $descr )?>",
              fontColor: "#ff6633",
              fontSize: 16,
              fontWeight: "normal",
              fontFamily: "Open Sans",
            }
            
<? 
}
?>
            
																     ],
				animationEnabled: false,
                backgroundColor: '#ffffff',
                // backgroundColor: '<?=$gray?>',
				axisX: { // this is the quarters
					gridColor: "#f0f0f0",
					// gridColor: "#525252",n
					labelFontColor: "#4f4f4f",
					labelFontFamily: "Open Sans",
					labelFontSize: "14",
					gridThickness:0,
					tickColor: '#dddddd',
					// tickColor: '<?=$gray?>',
					lineColor:"#dddddd",
					// lineColor:"#525252",
					tickLength: 5,
                    margin: 20
				},
				toolTip: {
                      // backgroundColor: "<?=$gray?>",
                      shared: false,
                      fontColor: "#4f4f4f",
                      fontStyle: "normal",
                      // fontColor: "#FFFFFF",
                      contentFormatter: function(e){
                            var thiscolumn = e.entries[0].dataSeries.name;
                                // this is like Q4-2015
                            var thisq = e.entries[0].dataPoint.label;
                                // this is like 20%
                            var thisy = e.entries[0].dataPoint.y;
                            val = thisy + "<?=$labelextra?><br>";
//                            alert( thisval );
                            var count = 0;
                            for(i = 0; i <  e.chart.options.data.length ; i++ )
                            {
                                    // this is like 1-5 times
                                var chartname = e.chart.options.data[i].name;
                                var thiscolor = e.chart.options.data[i].color;
//                                alert( e.chart.options.data[i].name );

                                var dpoints = e.chart.options.data[i].dataPoints;
                                for( j = 0; j < dpoints.length; j++ )
                                {
                                    if( dpoints[j].label == thisq && dpoints[j].y == thisy ) 
                                        val += ( "<a href='" + dpoints[j].url + "'><font color='" + thiscolor + "'>" + chartname + "</font></a><Br>" ) ;
                                }
                            }
                            return val;
                        }
				},
				// theme: "theme2",
				axisY: { // this is the data
					gridColor: "#f0f0f0",
					// gridColor: "#3c3c3c",
					tickLength: 0,
        			lineThickness:0,
        			gridThickness:1,
					labelFontColor: "#4f4f4f",
					// labelFontColor: "<?=$gray?>",
					tickColor: "#dddddd",
					// tickColor: "<?=$gray?>",
                    valueFormatString: " "
                    
                    
				},
				data: [
                    <?
                    $count = 0;
                    $cnt = 0;
                    foreach( $rows as $r=>$rname ) {
                        $cnt++;
                       ?>
            {
					type: "line",
                    markerType: "none",
                   <? if( $cnt > 6 && 1 == 0  ) { ?>visible: false, <? }?>
					indexLabelFontFamily: "Open Sans",
					showInLegend: true,
					lineThickness: 3,
					name: "<?=$rname?>",
					color: "<?=$colors[$count++]?>",
					dataPoints: [
                        <?
                        if( $count == count( $colors ) )
                        {
                            $count = 0;
                        }
                        $qcount = 0;
                        foreach( $quarterstorun as $q ) {
                            $qcount++;
                            list( $m, $y ) = explode( "/", $q );
                            $m = ($m-1)*3 + 1;
                            ?>                         
                                { label: "Q<?=str_replace( "/", "-", $q )?>", y: <?=formatYAxis( $dataforrows[$q][$r][0] )?>, indexLabel: "<?=$dataforrows[$q][$r][1]?>", indexLabelFontColor: "#4f4f4f", indexLabelFontWeight: "lighter", indexLabelFontSize: "12", click: function( e ) { document.location.href="<?=$dataforrows[$q][$r][3]?>"; }, cursor: "pointer", markerType: "circle", "url": "<?=$dataforrows[$q][$r][3]?>" },
                                    <? }?>                                
					]
				},
                <? } ?>
				],
				legend: {
                      verticalAlign: "top",
                      fontSize: 14,
                      fontColor: "#4f4f4f",
                      // fontColor: "#ffffff",
                      fontFamily: "Open Sans",
                      horizontalAlign: "center",
                      cursor: "pointer",
                      itemclick: function (e) {
                            if (typeof (e.dataSeries.visible) === "undefined" || e.dataSeries.visible) {
                                e.dataSeries.visible = false;
                            }
                            else {
                                e.dataSeries.visible = true;
                            }
                            chart.render();
                        }
                    }
                });
			chart.render();
		}
	</script>
<!-- end chart code -->
    
<?php include 'footer.php';?>