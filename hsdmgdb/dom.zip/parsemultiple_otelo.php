<?
db_query( "update pages set inactive = 1 where sourceid = $sourceid  " );
require_once "dom/simple_html_dom.php";

$filename = "otelosave/source_{$sourceid}.html";
$filename_decoded = "otelosave/source_{$sourceid}_decoded.txt";
printhref( $filename_decoded );
$pagecontents = pullFile( "https://www.otelo.de/api/v2/page/handy-mit-vertrag", $filename, $filename_decoded );
try
    {
    $inner = $pagecontents;
// $html = str_get_html( $pagecontents );
// $inner = json_decode( $html );
// print_r( $inner );
file_put_contents( $filename_decoded, print_r( $inner, true ) );
//	exit;
$already = array();

foreach( $inner->data->modules as $d )
    {
	//	echo( $d->{"_etype"} . "<br>" );
	if( $d->{"_etype"} == "hardware_list" )
	    {
		$hardware = $d->entities;
	    }
    }
foreach($hardware as $selectbox )
{
    if( $selectbox->{"_etype"} != "hardware_entity" ) continue;
    //    print_r( $selectbox );exit;
	$phonecode = $selectbox->{"group_id"};
    if( $already[$phonecode] ) continue;
    $already[$phonecode] = 1;
    $href= $selectbox->{"url_select"};
    $text = $selectbox->{"name"};
    $val = $phonecode;
    $thisfile = "otelosave/over_{$phonecode}.txt";
    file_put_contents( $thisfile, print_r( $selectbox, true ) );
    $thisfilejson = "otelosave/over_{$phonecode}.json";
    file_put_contents( $thisfile, json_encode( $selectbox ) );
		
    $current = db_query_first_cell( "select id from pages where sourceid = $sourceid and code = '$val'" );
    if( $current )
	{
	    echo( "update pages set inactive = 0, Name = '" . mysql_escape_string( $text ) . "', displayURL = '" . mysql_escape_string( $href ) . "' where id = $current<br>" );
	    db_query( "update pages set inactive = 0, Name = '" . mysql_escape_string( $text ) . "', displayURL = '" . mysql_escape_string( $href ) . "' where id = $current" );
	}
    else
	{
	    echo( "insert into pages ( sourceid, Name, displayURL, code, inactive, dateadded )  values ( '$sourceid', '" . mysql_escape_string( $text ) . "', '$href', '$val', 0, now() )<Br> " );
	    db_query( "insert into pages ( sourceid, Name, displayURL, code, inactive, dateadded )	values ( '$sourceid', '" . mysql_escape_string( $text ) . "', '$href', '$val', 0, now() ) " );
	    echo( "adding $text ($phonecode)" );
	}
}
    }
catch (\Throwable $err) {
    echo( "in error exception!" );
    print_r( $err );
    mail( "rachelc@gmail.com", "scraper error otelo  ($sourceid)!", print_r( $err, true ), "From: info@scraper.vireo.org" );
}
//exit;


try
    {
$filename = "otelosave/source_prepaid_{$sourceid}.html";
$filename_decoded = "otelosave/source_prepaid_{$sourceid}_decoded.txt";
$pagecontents = pullFile( "https://www.otelo.de/api/v2/page/handytarife/prepaid-tarife", $filename, $filename_decoded );
printhref( $filename );
// $html = str_get_html( $pagecontents );
// $scripts = $html->find( "script" );
// foreach( $scripts as $s )
// {
//     if( strpos( $s->innertext, "INITIAL_STATE" ) !== false )
// 	{
// 	    //				echo( "got in here" );
// 	    $inner = $s->innertext;
// 	    break;
// 	}
// }
// //                echo( $inner );exit;
// $inner = str_replace( "window.INITIAL_STATE = ", "", $inner );
// $inner = json_decode( $inner );
// 	print_r( $inner );
$inner = $pagecontents;
file_put_contents( "/tmp/inner", print_r( $inner, true ) );
// 	exit;
$hardware = "";
foreach( $inner->data->modules as $d )
    {
	//	echo( $d->{"_etype"} . "<br>" );
	if( $d->{"_etype"} == "tariff_list" )
	    {
		$hardware = $d->entities;
	    }
    }

foreach($hardware as $selectbox)
{
    //		echo( "a:" . $selectbox->outertext . "<br>\n\n") ;
    if( $selectbox->{"_etype"} != "tariff_entity" ) continue;
    //       print_r( $selectbox );exit;
    $phonecode = $selectbox->{"_eid"};
    $href= $selectbox->{"url_select"};
    $text = $selectbox->{"name"};
    $simonly = $selectbox->{"sim_only"};
    $val = $phonecode;
    $thisfile = "otelosave/over_{$phonecode}.txt";
    file_put_contents( $thisfile, print_r( $selectbox, true ) );
    $current = db_query_first_cell( "select id from pages where sourceid = $sourceid and isprepaid = 1 and code = '$val'" );
    if( $current )
	{
	    			echo( "update pages set inactive = 0, Name = '" . mysql_escape_string( $text ) . "', displayURL = '" . mysql_escape_string( $href ) . "' where id = $current<br>" );
	    db_query( "update pages set inactive = 0, Name = '" . mysql_escape_string( $text ) . "', displayURL = '" . mysql_escape_string( $href ) . "' where id = $current" );
	}
    else
	{
	    echo( "insert into pages ( sourceid, Name, displayURL, code, inactive, dateadded, isprepaid )  values ( '$sourceid', '" . mysql_escape_string( $text ) . "', '$href', '$val', 0, now(), 1 )<Br> " );
	    db_query( "insert into pages ( sourceid, Name, displayURL, code, inactive, dateadded, isprepaid, withouthandset )  values ( '$sourceid', '" . mysql_escape_string( $text ) . "', '$href', '$val', 0, now(), 1, '$simonly' ) " );
	    echo( "<Br>adding prea $text ($phonecode)" );
	}
}

    }
catch (\Throwable $err) {
    echo( "in error exception!" );
    print_r( $err );
    mail( "rachelc@gmail.com", "scraper error otelo prepaid  ($sourceid)!", print_r( $err, true ), "From: info@scraper.vireo.org" );
}

//exit;
try
    {
$filename = "otelosave/source_daten_{$sourceid}.html";
$filename_decoded = "otelosave/source_daten_{$sourceid}_decoded.txt";
$pagecontents = pullFile( "https://www.otelo.de/api/v2/page/handytarife/daten-tarife", $filename, $filename_decoded );
printhref( $filename );

// $filename = "otelosave/source_dataplan_{$sourceid}.html";
// $filename_decoded = "otelosave/source_dataplan_{$sourceid}_decoded.txt";
// $pagecontents = pullFile( "https://www.otelo.de/handytarife/daten-tarife", $filename );
// echo( "$filename_decoded<br>" );
// $html = str_get_html( $pagecontents );
// $scripts = $html->find( "script" );
// foreach( $scripts as $s )
// {
//     if( strpos( $s->innertext, "INITIAL_STATE" ) !== false )
// 	{
// 	    $inner = $s->innertext;
// 	    break;
// 	}
// }
// $inner = str_replace( "window.INITIAL_STATE = ", "", $inner );
// $inner = json_decode( $inner );
// //			print_r( $inner->entities->tariffEntity );
// file_put_contents( $filename_decoded, print_r( $inner, true ) );
// //	exit;

$inner = $pagecontents;
// file_put_contents( "/tmp/inner", print_r( $inner, true ) );
//  	exit;
$hardware = "";
foreach( $inner->data->modules as $d )
    {
	//	echo( $d->{"_etype"} . "<br>" );
	if( $d->{"_etype"} == "tariff_list" )
	    {
		$hardware = $d->entities;
	    }
    }

foreach($hardware as $selectbox)
{
    //		echo( "a:" . $selectbox->outertext . "<br>\n\n") ;
    if( $selectbox->{"_etype"} != "tariff_entity" ) continue;
    //		echo( "a:" . $selectbox->outertext . "<br>\n\n") ;
    $phonecode = $selectbox->{"eid"};
    $href= $selectbox->{"url_select"};
    if( !$href )
	$href= $selectbox->{"url_details"};
    $text = trim( $selectbox->{"name"} );
    if( !$text )
	{
	    $text = str_replace( "TariffEntity: ", "", $selectbox->{"etitle"} );
	}
    if( !trim( $text ) )
	{
	    echo( "NO TEXT: " ) ;
	    print_r( $selectbox );
	}
    $val = $phonecode;
    if( $text == "Surf-SIM" ) continue;
		
    $current = db_query_first_cell( "select id from pages where sourceid = $sourceid and code = '$val' and isdataplan = 1" );
    if( $current )
	{
	    echo( "update pages set inactive = 0, Name = '" . mysql_escape_string( $text ) . "', displayURL = '" . mysql_escape_string( $href ) . "' where id = $current<br>" );
	    db_query( "update pages set inactive = 0, Name = '" . mysql_escape_string( $text ) . "', displayURL = '" . mysql_escape_string( $href ) . "' where id = $current" );
	}
    else
	{
	    echo( "insert into pages ( sourceid, Name, displayURL, code, inactive, dateadded, isdataplan )	values ( '$sourceid', '" . mysql_escape_string( $text ) . "', '$href', '$val', 0, now(), 1 )<Br> " );
	    db_query( "insert into pages ( sourceid, Name, displayURL, code, inactive, dateadded, isdataplan )  values ( '$sourceid', '" . mysql_escape_string( $text ) . "', '$href', '$val', 0, now(), 1 ) " );
	    echo( "adding data plan $text ($phonecode)" );
	}
}

    }
catch (\Throwable $err) {
    echo( "in error exception!" );
    print_r( $err );
    mail( "rachelc@gmail.com", "scraper error otelo dataplan  ($sourceid)!", print_r( $err, true ), "From: info@scraper.vireo.org" );
}



try
    {
	
$filename = "otelosave/source_planonly_{$sourceid}.html";
$filename_decoded = "otelosave/source_planonly_{$sourceid}_decoded.txt";
$pagecontents = pullFile( "https://www.otelo.de/handytarife", $filename );
echo( "$filename_decoded<br>" );
$html = str_get_html( $pagecontents );
$scripts = $html->find( "script" );
foreach( $scripts as $s )
{
    if( strpos( $s->innertext, "INITIAL_STATE" ) !== false )
	{
	    $inner = $s->innertext;
	    break;
	}
}
$inner = str_replace( "window.INITIAL_STATE = ", "", $inner );
$inner = json_decode( $inner );
//			print_r( $inner->entities->tariffEntity );
file_put_contents( $filename_decoded, print_r( $inner, true ) );
//	exit;
// echo( "num: " . count( $inner->entities->tariffEntity ) );
// exit;
foreach($inner->entities->tariffEntity as $id=>$selectbox)
{
    //		echo( "HOLD UP: $id<br>" );
    $phonecode = $selectbox->{"eid"};
    $href= $selectbox->{"urlSelect"};
    if( !$href )
	$href= $selectbox->{"urlDetails"};
    $text = trim( $selectbox->{"type"} . " " . $selectbox->{"name"} );
    if( !$text )
	{
	    $text = str_replace( "TariffEntity: ", "", $selectbox->{"etitle"} );
	}
    if( !trim( $text ) )
	{
	    echo( "NO TEXT: " ) ;
	    print_r( $selectbox );
	}
    $val = $phonecode;
    //		echo( "text is :: " . $text. "<br>" );
    if( $text == "Surf-SIM" ) continue;
    if( strpos( $text, "Prepaid" ) !== false ) continue;
		
    $current = db_query_first_cell( "select id from pages where sourceid = $sourceid and code = '$val' and isdataplan = 1" );
    if( $current )
	{
	    echo( "update pages set inactive = 0, Name = '" . mysql_escape_string( $text ) . "', displayURL = '" . mysql_escape_string( $href ) . "' where id = $current<br>" );
	    db_query( "update pages set inactive = 0, Name = '" . mysql_escape_string( $text ) . "', displayURL = '" . mysql_escape_string( $href ) . "' where id = $current" );
	}
    else
	{
	    echo( "insert into pages ( sourceid, Name, displayURL, code, inactive, dateadded, isdataplan )	values ( '$sourceid', '" . mysql_escape_string( $text ) . "', '$href', '$val', 0, now(), 1 )<Br> " );
	    db_query( "insert into pages ( sourceid, Name, displayURL, code, inactive, dateadded, isdataplan )  values ( '$sourceid', '" . mysql_escape_string( $text ) . "', '$href', '$val', 0, now(), 1 ) " );
	    echo( "adding data plan $text ($phonecode)" );
	}
}

    }
catch (\Throwable $err) {
    echo( "in error exception!" );
    print_r( $err );
    mail( "rachelc@gmail.com", "scraper error otelo planonly  ($sourceid)!", print_r( $err, true ), "From: info@scraper.vireo.org" );
}


	
//	exit;
?>
